public class Game_of_peril {
    void diceroll(){
        int[] dice = {1,2,3,4,5,6};
        System.out.printf(":",dice[0]);
    }
    public static void main(String[] args){
    System.out.println("Welcome to Peril: Let's Play");
    System.out.printf("------------------------------");
    }
}
