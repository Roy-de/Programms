import java.lang.Character.*;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

class ColumnAlignment{
    public static boolean isNumeric(String str){
        for (char c : str.toCharArray())
        {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    public static void main(String args[]){
        //Read lines from file As2Q3
        //Display line text as follows.
        /*
            Right align numeric values (they can have one decimal or start with $)
            Centre align on numeric values or text that does not fall under numeric description.
            Left align text that is longer than column width.
        */ 

        //Ask user for column width.
        //Display each line aligned as described above. 
        //Include dot to visualize spaces.
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter column width.");
        int columnWidth = sc.nextInt();
        try{
            File file = new File("/As2Q3.txt");
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()){
                String line = reader.nextLine();
                int length = line.length();
                String dollar = "$";
                //Right indentation
                if ((isNumeric(line)==true) || (line.charAt(0) == dollar.charAt(0)))
                {
                    for (int i=0; i<(columnWidth-length); i++)
                        System.out.print(".");
                    System.out.print(line); 
                    System.out.println();
                }
                else if (length < columnWidth){
                    int temp = (columnWidth-length)/2;
                    for (int i=0; i<temp; i++)
                        System.out.print(".");
                    System.out.print(line);
                    for (int i=0; i<temp; i++)
                        System.out.print(".");
                    System.out.println();
                }
                else{
                    //Left indentation
                    System.out.println(line);                   
                }      
            }
            reader.close();
        }catch (FileNotFoundException  e){
            System.out.println("An error occured.");
            e.printStackTrace();
        }

    }
}